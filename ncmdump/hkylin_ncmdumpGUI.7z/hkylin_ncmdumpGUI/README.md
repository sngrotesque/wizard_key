# ncmdumpGUI

### 声明

网易云音乐ncm文件格式转换，基于[anonymous5l/ncmdump-gui](https://github.com/anonymous5l/ncmdump-gui)修改

尊重音乐版权，本项目仅方便已购买的音乐在其他软件或设备播放，请勿大范围传播或用于商业行为。

### 使用方法

1. Windows7及以上版本
2. 先安装`.NET Framework 4.6`（或其他兼容版本）
3. 然后运行`ncmdumpGUI.exe`
4. 根据界面提示操作即可。

### 开发环境

Visual Studio 2017

.NET Framework 4.6.1